package Panel;

public class AppointmentCounts {
}
