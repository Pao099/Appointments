package Panel;

public class Patient {
}
