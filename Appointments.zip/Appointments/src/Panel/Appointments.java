package Panel;

public class Appointments {
}
