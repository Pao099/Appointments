
package Entrance;

import java.sql.*;
import java.util.Properties;

import Entrance.Login.*;

public class Connect {
    // init database constants
    private static final String DATABASE_DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String DATABASE_URL = "jdbc:mysql://3.227.166.251:3306/U06ohA";
    private static final String USERNAME = "U06ohA";
    private static final String PASSWORD = "53688825418";
    private static final String MAX_POOL = "250";

    // init connection object
    private static Connection connection;
    // init properties object
    private static Properties properties;

    // create properties
    private static Properties getProperties() {
        if (properties == null) {
            properties = new Properties();
            properties.setProperty("user", USERNAME);
            properties.setProperty("password", PASSWORD);
            properties.setProperty("MaxPooledStatements", MAX_POOL);
        }
        return properties;
    }
    // connect database
    public static Connection connect() {System.out.println("Connecting database...");
        if (connection == null) {
            try {
                Class.forName(DATABASE_DRIVER);
                Connection conn = DriverManager.getConnection(DATABASE_URL, getProperties());
                System.out.println("Database connected!");

            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
                throw new IllegalStateException("Cannot connect the database!", e);
            }
        }
        return connection;
    }



//query

    public static void login() {
        String username = null;
        String password=null;
        String pin=null;
        try {
            Statement statement = Connect.connect().createStatement();
            String query = "SELECT * FROM counselor WHERE c_id='1' AND c_name='" + username + "' AND c_password='" + password + "' AND c_pin='" + pin + "'";
            ResultSet results = statement.executeQuery(query);

        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
    }


    // disconnect database
    public static void disconnect() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}