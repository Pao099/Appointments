package Entrance;

import javafx.collections.transformation.TransformationList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.InputMethodTextRun;

import java.awt.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Login {


   @FXML
   private static PasswordField  pwdfx;
    // static String password= pwdfx.getText();
    @FXML
    private static PasswordField pinfx;
     //static String pin= pinfx.getText();

    @FXML private static TextField ident;
     //static String username= ident.getText();
    @FXML private Label maintime;
    @FXML private Button loginbutton;
    @FXML private Label localtime;
    @FXML private Label idlabel;
    @FXML private Label passwordlabel;
    @FXML private Label pinlabel;

    @FXML private static void login() {

        try {
            String username= ident.getText();
            String password= pwdfx.getText();
            String pin= pinfx.getText();
            Statement statement = Connect.connect().createStatement();
            String query = "SELECT * FROM counselor WHERE c_id='1' AND c_name='" + username + "' AND c_password='" + password + "' AND c_pin='" + pin + "'";
            ResultSet results = statement.executeQuery(query);

        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
    }


    public void handleLogin(ActionEvent event) { Login.login();
        event.consume();
    }


}
